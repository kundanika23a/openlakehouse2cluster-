 auto aggi
 iface aggi inet static 
 hwaddress ether 22:44:77:88:D5:96
 address 10.44.15.196
 netmask 255.255.255.248
 mtu 1500
 slaves int1 int2
 bond_mode 4
 bond_miimon 100
 bond_downdelay 200
 bond_updelay 200
 bond_lacp_rate slow
 bond_xmit_hash_policy layer3+4
 post-up /sbin/ethtool -K aggi tx off tso off
 
 auto agge
 iface agge inet manual

 auto br0
 iface br0 inet static
 bridge_ports agge
 hwaddress ether 22:44:77:88:D5:98
 address 188.44.133.76
 netmask 255.255.255.248
 gateway 188.44.133.75
 slaves ext1 ext2
 bond_mode 4
 bond_miimon 100
 bond_downdelay 200
 bond_updelay 200
 bond_lacp_rate slow
 bond_xmit_hash_policy layer3+4
 post-up /sbin/ethtool -K agge tx off tso off
 
 up route add -net 10.0.0.0/8 gw 10.44.15.117 dev aggi
 up route add -net 192.168.0.0/16 gw 10.44.15.117 dev aggi
 up route add -net 188.44.208.0/21 gw 10.44.15.117 dev aggi
 
 auto int1
 iface int1 inet manual
 bond-master aggi
 
 auto int2
 iface int2 inet manual
 bond-master aggi
 
 auto ext1
 iface ext1 inet manual
 bond-master agge
 
 auto ext2
 iface ext2 inet manual
 bond-master agge
 
 auto eth1
 iface eth1 inet manual

 auto lo
 iface lo inet loopback
 
source /etc/network/interfaces.d/*.cfg
