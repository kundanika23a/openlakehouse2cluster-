# Progress

Phase 0 discovery is written. Phases 1–12 have code in the repository. Their gates have not passed. No live deploy, test report, or idempotent second run exists.

| Phase | What is in the repo | Gate |
|---|---|---|
| 0 | Inventory, versions, RootDSE, DNS, CA fingerprint in `docs/DECISIONS.md` | Discovery written. Bind and OU confirmed. CA trust and PTR still open. |
| 1 | `bootstrap.yml`, `preflight.yml`, `prerequisites.yml`, `identity.yml` | Not run on the six nodes. Preflight is expected red. |
| 2 | `artifact_repo` play; downloads and `manifest.lock.yml` are not present | Not passed. |
| 3 | `keytabs.yml` orders PKI then keytabs | Not passed. No keytab has been kinit'd. |
| 4 | PostgreSQL and ZooKeeper plays | Not passed. |
| 5 | Ozone plays and `variables` ozone-site | Not passed. Storage-scheme spike not run. `ofs` is the configured scheme. |
| 6 | Kafka and Solr plays | Not passed. |
| 7 | Ranger plays | Not passed. |
| 8 | YARN, HMS, Iceberg, Spark, Kyuubi, Trino | Not passed. |
| 9 | Atlas plays, `governance.yml` | Not passed. |
| 10 | Knox and HAProxy | Not passed. |
| 11 | Backup, restore, upgrade, add, decommission, rotation | Not passed. |
| 12 | `validate.yml` and `tests/` | Not passed. `validate.yml` fails until `validate_live=true`, which has not been used. |

Blockers: AD CA trust, PTR mismatches for test3 and test6, disk format left false, compatibility gates not executed. The encrypted vault and the OpenLakeHouse bind are in place.
