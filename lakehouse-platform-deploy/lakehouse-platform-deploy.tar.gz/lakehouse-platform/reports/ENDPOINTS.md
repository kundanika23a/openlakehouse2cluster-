# Endpoints

Planned URLs. Nothing in this file has been fetched from the cluster.

Knox is the user front door on `https://lakehouse.infra.alephys.com:8443` when DNS is delegated, or through HAProxy on test3 (`10.1.0.170:443`) while `load_balancer_vip` is empty. There is no VIP.

| Surface | URL |
|---|---|
| Knox UI topology | `https://clientopensourcetest1.infra.alephys.com:8443/gateway/ui/` |
| Knox API topology | `https://clientopensourcetest1.infra.alephys.com:8443/gateway/api/` |
| Trino coordinator | `https://clientopensourcetest1.infra.alephys.com:8444` |
| Trino JDBC | `jdbc:trino://clientopensourcetest1.infra.alephys.com:8444` |
| Kyuubi JDBC | `jdbc:hive2://clientopensourcetest1.infra.alephys.com:10009/;principal=kyuubi/clientopensourcetest1.infra.alephys.com@ADALEPHYS.COM` |
| Kyuubi REST | `https://clientopensourcetest1.infra.alephys.com:10099` |
| Ranger | `https://clientopensourcetest3.infra.alephys.com:6182` |
| Atlas | `https://clientopensourcetest2.infra.alephys.com:21443` |
| YARN RM | `https://clientopensourcetest1.infra.alephys.com:8090` |
| Spark history | `https://clientopensourcetest2.infra.alephys.com:18480` |
| Ozone S3 | `https://clientopensourcetest4.infra.alephys.com:9879` |
| Ozone HttpFS | `https://clientopensourcetest6.infra.alephys.com:14001` |
| Grafana | `https://clientopensourcetest3.infra.alephys.com:3000` |

Principals use the `_HOST` form in service config and the node FQDN in a client string: `hive/<fqdn>@ADALEPHYS.COM`, `trino/<fqdn>@ADALEPHYS.COM`, `kafka/<fqdn>@ADALEPHYS.COM`.

Client snippets belong in `/etc/lakehouse` after a deploy. Sample Trino CLI: `--server https://clientopensourcetest1.infra.alephys.com:8444`. Sample spark-submit uses `--principal` and a keytab path under `/etc/security/keytabs`, which is not created until keytabs have been issued.
