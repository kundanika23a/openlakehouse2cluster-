#!/usr/bin/env python3
"""Compare a file with a published checksum.

Apache publishes hex digests. Maven Central publishes base64 digests.
Prints the hex digest on success.
"""

import base64
import hashlib
import pathlib
import sys


def main() -> int:
    if len(sys.argv) != 4:
        print("usage: verify_digest.py FILE CHECKSUM_FILE sha256|sha512", file=sys.stderr)
        return 2
    path, checksum_file, algorithm = sys.argv[1:]
    if algorithm not in ("sha256", "sha512"):
        print("unsupported algorithm", file=sys.stderr)
        return 2
    data = pathlib.Path(path).read_bytes()
    text = pathlib.Path(checksum_file).read_text(encoding="utf-8")
    hex_len = 128 if algorithm == "sha512" else 64
    hexdigits = set("0123456789abcdefABCDEF")
    tokens = []
    for raw in text.replace("=", " ").replace(":", " ").replace("(", " ").replace(")", " ").split():
        if raw and all(character in hexdigits for character in raw):
            tokens.append(raw.lower())
    exact = [token for token in tokens if len(token) == hex_len]
    if exact:
        published = exact[0]
    else:
        grouped = "".join(token for token in tokens if len(token) in (8, 16, 32, 64))
        published = grouped[:hex_len] if len(grouped) >= hex_len else ""
    hasher = hashlib.new(algorithm)
    hasher.update(data)
    hex_digest = hasher.hexdigest()
    b64_digest = base64.b64encode(hasher.digest()).decode("ascii")
    if published.lower() not in (hex_digest, b64_digest):
        print(hex_digest)
        print("checksum mismatch", file=sys.stderr)
        return 1
    print(hex_digest)
    return 0


if __name__ == "__main__":
    sys.exit(main())
