#!/usr/bin/env python3
"""kinit from a mode-0400 password file. The password is not an argument."""

from __future__ import annotations

import os
import pty
import select
import stat
import sys
import time
from pathlib import Path


def main() -> None:
    principal = os.environ["KINIT_PRINCIPAL"]
    password_path = Path(os.environ["KINIT_PASSWORD_FILE"])
    ccache = os.environ.get("KRB5CCNAME", "")
    mode = password_path.stat().st_mode
    if mode & (stat.S_IRWXG | stat.S_IRWXO):
        sys.exit(f"refusing to read {password_path}: mode must be 0400")
    password = password_path.read_bytes()
    if password.endswith(b"\n"):
        password = password[:-1]
    pid, fd = pty.fork()
    if pid == 0:
        if ccache:
            os.environ["KRB5CCNAME"] = ccache
        os.execvp("kinit", ["kinit", principal])
    sent = False
    deadline = time.time() + 30
    try:
        while time.time() < deadline:
            ready, _, _ = select.select([fd], [], [], 1)
            if not ready:
                finished, _status = os.waitpid(pid, os.WNOHANG)
                if finished == pid:
                    break
                continue
            try:
                chunk = os.read(fd, 4096)
            except OSError:
                break
            if not chunk:
                break
            if not sent and b"Password" in chunk:
                os.write(fd, password + b"\n")
                sent = True
        _pid, status = os.waitpid(pid, 0)
    finally:
        try:
            os.close(fd)
        except OSError:
            pass
    if os.waitstatus_to_exitcode(status) != 0 or not sent:
        sys.exit(f"kinit failed for {principal}")


if __name__ == "__main__":
    main()
