#!/usr/bin/env python3
"""Local plaintext listener that opens TLS to this node's ZooKeeper client port.

Kyuubi 1.11 ships ZooKeeper 3.4.14, which has no TLS socket. ZooKeeper documents
TLS only through ClientCnxnSocketNetty. This proxy performs that TLS handshake
with the host certificate so Kyuubi can use its built-in client on localhost.
"""
import select
import socket
import ssl
import sys
import threading


def pump(left, right):
    sockets = [left, right]
    try:
        while True:
            ready, _, _ = select.select(sockets, [], [], 300)
            if not ready:
                continue
            for source in ready:
                data = source.recv(65536)
                if not data:
                    return
                target = right if source is left else left
                target.sendall(data)
    finally:
        for connection in sockets:
            try:
                connection.close()
            except OSError:
                pass


def main():
    listen_host, listen_port, target_host, target_port, cert, key, ca = sys.argv[1:8]
    context = ssl.create_default_context(ssl.Purpose.SERVER_AUTH, cafile=ca)
    context.load_cert_chain(certfile=cert, keyfile=key)
    context.minimum_version = ssl.TLSVersion.TLSv1_2
    listener = socket.socket()
    listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    listener.bind((listen_host, int(listen_port)))
    listener.listen(64)
    while True:
        client, _ = listener.accept()

        def handle(client=client):
            server = socket.create_connection((target_host, int(target_port)), 10)
            secure = context.wrap_socket(server, server_hostname=target_host)
            pump(client, secure)

        threading.Thread(target=handle, daemon=True).start()


if __name__ == "__main__":
    main()
