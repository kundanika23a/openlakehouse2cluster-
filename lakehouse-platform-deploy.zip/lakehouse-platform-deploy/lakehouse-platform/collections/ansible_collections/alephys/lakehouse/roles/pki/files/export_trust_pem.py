#!/usr/bin/env python3
"""Write a PEM trust bundle from certificates that already exist on the host."""

import pathlib
import sys


def main():
    dest = pathlib.Path(sys.argv[1])
    chunks = []
    seen = set()
    for raw in sys.argv[2:]:
        path = pathlib.Path(raw)
        if not path.is_file():
            continue
        text = path.read_text(encoding="utf-8")
        if "BEGIN CERTIFICATE" not in text:
            sys.stderr.write("refusing a file that is not a PEM certificate\n")
            return 2
        normalized = text.strip() + "\n"
        if normalized in seen:
            continue
        seen.add(normalized)
        chunks.append(normalized)
    if not chunks:
        sys.stderr.write("no CA certificates were available for the trust bundle\n")
        return 2
    body = "".join(chunks)
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.is_file() and dest.read_text(encoding="utf-8") == body:
        print("ok")
        return 0
    dest.write_text(body, encoding="utf-8")
    print("changed")
    return 0


if __name__ == "__main__":
    sys.exit(main())
