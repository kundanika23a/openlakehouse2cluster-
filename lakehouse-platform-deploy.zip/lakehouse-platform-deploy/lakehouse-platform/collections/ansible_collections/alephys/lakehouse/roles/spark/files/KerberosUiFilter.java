package com.alephys.lakehouse.spark;

import java.io.IOException;
import java.security.Principal;
import java.security.PrivilegedExceptionAction;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import javax.security.auth.Subject;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.login.AppConfigurationEntry;
import javax.security.auth.login.Configuration;
import javax.security.auth.login.LoginContext;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletRequestWrapper;
import jakarta.servlet.http.HttpServletResponse;
import org.ietf.jgss.GSSContext;
import org.ietf.jgss.GSSManager;

/**
 * SPNEGO filter for Spark 4. Unauthenticated requests are rejected.
 * The Hadoop AuthenticationFilter still implements the older servlet API.
 */
public final class KerberosUiFilter implements Filter {
    private static final String COOKIE = "spark.kerberos.ui";
    private static final long COOKIE_TTL_MS = 8L * 60L * 60L * 1000L;

    private Subject serviceSubject;
    private String realm;
    private byte[] cookieKey;
    private String proxyUser = "";
    private Set<String> proxyHosts = Collections.emptySet();

    @Override
    public void init(FilterConfig config) throws ServletException {
        String principal = required(config, "principal");
        String keytab = required(config, "keytab");
        int at = principal.lastIndexOf('@');
        if (at < 1 || at == principal.length() - 1) {
            throw new ServletException("Kerberos principal must include a realm");
        }
        realm = principal.substring(at + 1);
        proxyUser = optional(config, "proxy-user");
        proxyHosts = hosts(optional(config, "proxy-hosts"));
        if (!proxyUser.isEmpty() && proxyHosts.isEmpty()) {
            throw new ServletException("Knox impersonation requires proxy-hosts");
        }
        cookieKey = new byte[32];
        new SecureRandom().nextBytes(cookieKey);
        try {
            LoginContext context = new LoginContext("SparkSpnego", null, (CallbackHandler) null, jaas(principal, keytab));
            context.login();
            serviceSubject = context.getSubject();
        } catch (Exception e) {
            throw new ServletException("Kerberos acceptor login failed", e);
        }
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        if (!(request instanceof HttpServletRequest) || !(response instanceof HttpServletResponse)) {
            throw new ServletException("Spark UI authentication requires HTTP");
        }
        HttpServletRequest http = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        String cookieUser = userFromCookie(http);
        if (cookieUser != null) {
            chain.doFilter(new UserRequest(http, cookieUser), httpResponse);
            return;
        }
        String authorization = http.getHeader("Authorization");
        if (authorization == null || !authorization.regionMatches(true, 0, "Negotiate ", 0, 10)) {
            challenge(httpResponse, null);
            return;
        }
        byte[] token;
        try {
            token = Base64.getDecoder().decode(authorization.substring(10).trim());
        } catch (IllegalArgumentException e) {
            challenge(httpResponse, null);
            return;
        }
        AcceptResult accepted;
        try {
            accepted = Subject.doAs(serviceSubject, (PrivilegedExceptionAction<AcceptResult>) () -> accept(token));
        } catch (Exception e) {
            challenge(httpResponse, null);
            return;
        }
        if (!accepted.established) {
            challenge(httpResponse, accepted.outputToken);
            return;
        }
        String user = shortName(accepted.principal);
        if (user == null) {
            httpResponse.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }
        String effective = impersonated(http, user);
        if (effective == null) {
            httpResponse.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }
        addCookie(httpResponse, effective);
        chain.doFilter(new UserRequest(http, effective), httpResponse);
    }

    @Override
    public void destroy() {
        serviceSubject = null;
        cookieKey = null;
    }

    private AcceptResult accept(byte[] token) throws Exception {
        GSSContext context = GSSManager.getInstance().createContext((org.ietf.jgss.GSSCredential) null);
        try {
            byte[] output = context.acceptSecContext(token, 0, token.length);
            boolean established = context.isEstablished();
            String name = established ? context.getSrcName().toString() : null;
            return new AcceptResult(established, name, output);
        } finally {
            context.dispose();
        }
    }

    private String impersonated(HttpServletRequest request, String user) {
        String doAs = request.getParameter("doAs");
        if (doAs == null || doAs.isEmpty()) {
            return user;
        }
        if (!proxyUser.equals(user) || !fromProxyHost(request) || !isShortName(doAs)) {
            return null;
        }
        return doAs;
    }

    private boolean fromProxyHost(HttpServletRequest request) {
        String remoteHost = request.getRemoteHost();
        String remoteAddress = request.getRemoteAddr();
        return proxyHosts.contains(remoteHost) || proxyHosts.contains(remoteAddress);
    }

    private static boolean isShortName(String user) {
        if (user == null || user.isEmpty() || user.length() > 64) {
            return false;
        }
        for (int i = 0; i < user.length(); i++) {
            char c = user.charAt(i);
            boolean ok = (c >= 'a' && c <= 'z')
                    || (c >= 'A' && c <= 'Z')
                    || (c >= '0' && c <= '9')
                    || c == '-' || c == '_' || c == '.';
            if (!ok) {
                return false;
            }
        }
        return user.indexOf("..") < 0;
    }

    private static Set<String> hosts(String raw) {
        if (raw == null || raw.isEmpty()) {
            return Collections.emptySet();
        }
        Set<String> hosts = new HashSet<String>();
        for (String host : raw.split(",")) {
            String trimmed = host.trim();
            if (!trimmed.isEmpty()) {
                hosts.add(trimmed);
            }
        }
        return hosts;
    }

    private String shortName(String principal) {
        if (principal == null || !principal.endsWith("@" + realm)) {
            return null;
        }
        String withoutRealm = principal.substring(0, principal.length() - realm.length() - 1);
        int slash = withoutRealm.indexOf('/');
        String name = slash >= 0 ? withoutRealm.substring(0, slash) : withoutRealm;
        if (name.isEmpty() || name.indexOf('@') >= 0) {
            return null;
        }
        return name;
    }

    private void challenge(HttpServletResponse response, byte[] token) throws IOException {
        if (token != null && token.length > 0) {
            response.setHeader("WWW-Authenticate", "Negotiate " + Base64.getEncoder().encodeToString(token));
        } else {
            response.setHeader("WWW-Authenticate", "Negotiate");
        }
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        response.setContentType("text/plain");
        response.getWriter().write("Authentication required\n");
    }

    private void addCookie(HttpServletResponse response, String user) throws ServletException {
        long expiry = System.currentTimeMillis() + COOKIE_TTL_MS;
        String payload = user + "\n" + expiry;
        String value = Base64.getUrlEncoder().withoutPadding().encodeToString(
                (payload + "\n" + sign(payload)).getBytes(java.nio.charset.StandardCharsets.UTF_8));
        Cookie cookie = new Cookie(COOKIE, value);
        cookie.setHttpOnly(true);
        cookie.setSecure(true);
        cookie.setPath("/");
        cookie.setMaxAge((int) (COOKIE_TTL_MS / 1000L));
        response.addCookie(cookie);
    }

    private String userFromCookie(HttpServletRequest request) {
        Cookie[] cookies = request.getCookies();
        if (cookies == null) {
            return null;
        }
        for (Cookie cookie : cookies) {
            if (!COOKIE.equals(cookie.getName())) {
                continue;
            }
            try {
                String raw = new String(Base64.getUrlDecoder().decode(cookie.getValue()), java.nio.charset.StandardCharsets.UTF_8);
                int first = raw.indexOf('\n');
                int second = raw.indexOf('\n', first + 1);
                if (first < 1 || second < 0) {
                    return null;
                }
                String user = raw.substring(0, first);
                long expiry = Long.parseLong(raw.substring(first + 1, second));
                String mac = raw.substring(second + 1);
                if (expiry < System.currentTimeMillis()) {
                    return null;
                }
                if (!mac.equals(sign(user + "\n" + expiry)) || user.indexOf('@') >= 0 || user.indexOf('/') >= 0) {
                    return null;
                }
                return user;
            } catch (RuntimeException | ServletException e) {
                return null;
            }
        }
        return null;
    }

    private String sign(String payload) throws ServletException {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(cookieKey, "HmacSHA256"));
            return Base64.getUrlEncoder().withoutPadding().encodeToString(mac.doFinal(payload.getBytes(java.nio.charset.StandardCharsets.UTF_8)));
        } catch (Exception e) {
            throw new ServletException("Could not sign the authentication cookie", e);
        }
    }

    private static String optional(FilterConfig config, String name) {
        String value = config.getInitParameter(name);
        return value == null ? "" : value.trim();
    }

    private static String required(FilterConfig config, String name) throws ServletException {
        String value = config.getInitParameter(name);
        if (value == null || value.trim().isEmpty()) {
            throw new ServletException("Missing Kerberos UI filter parameter " + name);
        }
        return value.trim();
    }

    private static Configuration jaas(String principal, String keytab) {
        return new Configuration() {
            @Override
            public AppConfigurationEntry[] getAppConfigurationEntry(String name) {
                Map<String, String> options = new HashMap<String, String>();
                options.put("useKeyTab", "true");
                options.put("keyTab", keytab);
                options.put("principal", principal);
                options.put("storeKey", "true");
                options.put("isInitiator", "false");
                options.put("refreshKrb5Config", "true");
                return new AppConfigurationEntry[] {
                    new AppConfigurationEntry(
                            "com.sun.security.auth.module.Krb5LoginModule",
                            AppConfigurationEntry.LoginModuleControlFlag.REQUIRED,
                            options)
                };
            }
        };
    }

    private static final class AcceptResult {
        private final boolean established;
        private final String principal;
        private final byte[] outputToken;

        private AcceptResult(boolean established, String principal, byte[] outputToken) {
            this.established = established;
            this.principal = principal;
            this.outputToken = outputToken;
        }
    }

    private static final class UserRequest extends HttpServletRequestWrapper {
        private final String user;

        private UserRequest(HttpServletRequest request, String user) {
            super(request);
            this.user = user;
        }

        @Override
        public String getRemoteUser() {
            return user;
        }

        @Override
        public Principal getUserPrincipal() {
            return new Principal() {
                @Override
                public String getName() {
                    return user;
                }
            };
        }
    }
}
