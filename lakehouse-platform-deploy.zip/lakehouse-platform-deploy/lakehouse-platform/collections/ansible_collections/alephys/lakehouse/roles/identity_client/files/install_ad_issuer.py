#!/usr/bin/env python3
"""Save the AD issuer that signed the pinned domain-controller certificate."""

import base64
import pathlib
import subprocess
import sys

ldif_path, issuer_path, leaf_path = sys.argv[1:4]
text = pathlib.Path(ldif_path).read_text()
chunks = [line.split(":: ", 1)[1].strip() for line in text.splitlines() if ":: " in line]
if not chunks:
    sys.stderr.write("The directory did not return a CA certificate.\n")
    sys.exit(1)
der_path = issuer_path + ".der"
pathlib.Path(der_path).write_bytes(base64.b64decode("".join(chunks)))
converted = subprocess.run(
    ["openssl", "x509", "-in", der_path, "-out", issuer_path],
    capture_output=True,
    text=True,
)
pathlib.Path(der_path).unlink(missing_ok=True)
if converted.returncode != 0:
    sys.stderr.write(converted.stderr or "Could not write the issuer as PEM.\n")
    sys.exit(converted.returncode)
verify = subprocess.run(
    ["openssl", "verify", "-CAfile", issuer_path, leaf_path],
    capture_output=True,
    text=True,
)
if verify.returncode != 0:
    sys.stderr.write(verify.stderr or verify.stdout)
    sys.exit(verify.returncode)
