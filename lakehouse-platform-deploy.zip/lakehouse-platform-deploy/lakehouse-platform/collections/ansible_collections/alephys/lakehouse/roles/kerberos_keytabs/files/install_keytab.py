#!/usr/bin/env python3
"""Install a keytab with a temp file and an atomic rename.

The base64 payload is read from KT_B64. Nothing is printed.
"""

from __future__ import annotations

import base64
import grp
import os
import pwd
import stat
import sys
import tempfile
from pathlib import Path


def main() -> None:
    destination = Path(os.environ["KT_DEST"])
    payload = base64.b64decode(os.environ["KT_B64"], validate=True)
    mode = int(os.environ.get("KT_MODE", "0400"), 8)
    user = pwd.getpwnam(os.environ["KT_OWNER"])
    group = grp.getgrnam(os.environ["KT_GROUP"])
    destination.parent.mkdir(parents=True, exist_ok=True)
    os.chmod(destination.parent, 0o750)
    fd, temporary_name = tempfile.mkstemp(
        prefix=destination.name + ".",
        dir=str(destination.parent),
    )
    temporary = Path(temporary_name)
    try:
        os.write(fd, payload)
        os.fchown(fd, user.pw_uid, group.gr_gid)
        os.fchmod(fd, mode)
        os.close(fd)
        fd = -1
        os.replace(temporary, destination)
        os.chown(destination, user.pw_uid, group.gr_gid)
        os.chmod(destination, stat.S_IMODE(mode))
    finally:
        if fd >= 0:
            os.close(fd)
        if temporary.exists():
            temporary.unlink()
    written = destination.stat()
    if written.st_size != len(payload):
        sys.exit(f"keytab {destination} was truncated")


if __name__ == "__main__":
    main()
