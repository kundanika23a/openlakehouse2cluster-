#!/usr/bin/python3
"""Create the Atlas Solr collections when they are absent.

Prints ``changed`` or ``unchanged``. JanusGraph addresses vertex_index,
edge_index, and fulltext_index. atlas_janus is the collection and configset
this platform names. The script does not delete or rewrite existing collections.
"""

import json
import os
import subprocess
import sys


def main() -> int:
    os.environ["KRB5CCNAME"] = sys.argv[1]
    base, ca, config, replication = sys.argv[2:6]
    names = ["atlas_janus", "vertex_index", "edge_index", "fulltext_index"]
    listed = curl(
        ca,
        [f"{base}/solr/admin/collections?action=LIST&wt=json"],
    )
    if listed.returncode != 0:
        sys.stderr.write(listed.stderr or listed.stdout)
        return listed.returncode or 1
    try:
        existing = json.loads(listed.stdout).get("collections", [])
    except json.JSONDecodeError:
        sys.stderr.write(listed.stdout)
        return 1
    changed = False
    for name in names:
        if name in existing:
            continue
        created = curl(
            ca,
            [
                f"{base}/solr/admin/collections",
                "-G",
                "--fail",
                "--data-urlencode",
                "action=CREATE",
                "--data-urlencode",
                f"name={name}",
                "--data-urlencode",
                "numShards=1",
                "--data-urlencode",
                f"replicationFactor={replication}",
                "--data-urlencode",
                f"collection.configName={config}",
                "--data-urlencode",
                "wt=json",
            ],
        )
        if created.returncode != 0:
            sys.stderr.write(created.stderr or created.stdout)
            return created.returncode or 1
        changed = True
    print("changed" if changed else "unchanged")
    return 0


def curl(ca, args):
    return subprocess.run(
        ["curl", "--silent", "--show-error", "--cacert", ca, "--negotiate", "-u", ":"] + args,
        capture_output=True,
        text=True,
        check=False,
    )


if __name__ == "__main__":
    sys.exit(main())
