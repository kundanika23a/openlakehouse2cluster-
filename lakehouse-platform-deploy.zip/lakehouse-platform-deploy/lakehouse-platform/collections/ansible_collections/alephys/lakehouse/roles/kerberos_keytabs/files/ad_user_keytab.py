#!/usr/bin/env python3
"""Write an AES-only MIT keytab for an AD user account.

Used by the adcli path. The salt and PBKDF2 count come from the KDC
(KRB5_TRACE during kinit), then RFC 3962 string-to-key produces the
long-term AES128 and AES256 keys. RC4 and DES are never written.

Passwords are read from mode-0400 files. They are not accepted as
arguments and are not printed.
"""

from __future__ import annotations

import argparse
import hashlib
import math
import os
import pty
import re
import select
import stat
import struct
import subprocess
import sys
import tempfile
import time
from pathlib import Path


AES128 = 17
AES256 = 18
NAME_TYPE_PRINCIPAL = 1


def _rotate_right(data: bytes, bits: int) -> bytearray:
    data_b = bytearray(data)
    width = len(data_b) * 8
    bits %= width
    if bits == 0:
        return data_b
    byte_shift = bits // 8
    bit_shift = bits % 8
    rotated = bytearray(len(data_b))
    for index in range(len(data_b)):
        left = data_b[(index - byte_shift) % len(data_b)]
        right = data_b[(index - byte_shift - 1) % len(data_b)]
        rotated[index] = ((left >> bit_shift) | ((right << (8 - bit_shift)) & 0xFF)) & 0xFF
    return rotated


def _add_ones_complement(left: bytes, right: bytes) -> bytes:
    result = bytearray(len(left))
    carry = 0
    for index in range(len(left) - 1, -1, -1):
        total = left[index] + right[index] + carry
        result[index] = total & 0xFF
        carry = total >> 8
    while carry:
        progressed = False
        for index in range(len(result) - 1, -1, -1):
            total = result[index] + carry
            result[index] = total & 0xFF
            carry = total >> 8
            progressed = True
            if carry == 0:
                break
        if not progressed:
            break
    return bytes(result)


def nfold(data: bytes, nbytes: int) -> bytes:
    """RFC 3961 n-fold."""
    inlen = len(data)
    lcm_len = inlen * nbytes // math.gcd(inlen, nbytes)
    folded = bytearray(lcm_len)
    copies = lcm_len // inlen
    for index in range(copies):
        rotated = _rotate_right(data, 13 * index)
        start = index * inlen
        folded[start:start + inlen] = rotated
    accumulator = bytes(nbytes)
    for offset in range(0, lcm_len, nbytes):
        accumulator = _add_ones_complement(accumulator, folded[offset:offset + nbytes])
    return accumulator


def _aes_ecb_encrypt(key: bytes, block: bytes) -> bytes:
    if len(block) != 16:
        raise ValueError("AES block must be 16 bytes")
    cipher = {16: "aes-128-ecb", 32: "aes-256-ecb"}[len(key)]
    proc = subprocess.run(
        ["openssl", "enc", f"-{cipher}", "-nopad", "-K", key.hex(), "-iv", "00" * 16],
        input=block,
        capture_output=True,
        check=False,
    )
    if proc.returncode != 0 or len(proc.stdout) < 16:
        raise RuntimeError("openssl AES encryption failed")
    return proc.stdout[:16]


def _derive_key(base_key: bytes, constant: bytes, nbytes: int) -> bytes:
    block = nfold(constant, 16)
    output = b""
    while len(output) < nbytes:
        block = _aes_ecb_encrypt(base_key, block)
        output += block
    return output[:nbytes]


def string_to_key(password: str, salt: str, iterations: int, key_bytes: int) -> bytes:
    """RFC 3962 AES string-to-key."""
    seed = hashlib.pbkdf2_hmac(
        "sha1",
        password.encode("utf-8"),
        salt.encode("utf-8"),
        iterations,
        key_bytes,
    )
    return _derive_key(seed, b"kerberos", key_bytes)


def _counted(payload: bytes) -> bytes:
    return struct.pack("!H", len(payload)) + payload


def keytab_entry(principal: str, kvno: int, enctype: int, key: bytes, timestamp: int) -> bytes:
    """One MIT keytab v2 entry, including the leading length."""
    if "@" not in principal:
        raise ValueError(f"principal {principal} has no realm")
    body_name, realm = principal.rsplit("@", 1)
    components = body_name.split("/")
    body = struct.pack("!H", len(components))
    body += _counted(realm.encode("utf-8"))
    for component in components:
        body += _counted(component.encode("utf-8"))
    body += struct.pack("!II", NAME_TYPE_PRINCIPAL, timestamp)
    body += struct.pack("!B", kvno & 0xFF)
    body += struct.pack("!H", enctype)
    body += _counted(key)
    body += struct.pack("!I", kvno)
    return struct.pack("!i", len(body)) + body


def write_keytab(path: Path, principal: str, kvno: int, keys: dict[int, bytes]) -> None:
    timestamp = int(time.time())
    blob = struct.pack("!H", 0x0502)
    for enctype, key in keys.items():
        blob += keytab_entry(principal, kvno, enctype, key, timestamp)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=path.name + ".", dir=str(path.parent))
    try:
        os.write(fd, blob)
        os.fchmod(fd, 0o400)
        os.close(fd)
        fd = -1
        os.replace(temporary, path)
        os.chmod(path, 0o400)
    finally:
        if fd >= 0:
            os.close(fd)
        if os.path.exists(temporary):
            os.unlink(temporary)


def read_password(path: Path) -> str:
    raw = path.read_bytes()
    mode = path.stat().st_mode
    if mode & (stat.S_IRWXG | stat.S_IRWXO):
        raise SystemExit(f"refusing to read {path}: mode must be 0400")
    if raw.endswith(b"\n"):
        raw = raw[:-1]
    return raw.decode("utf-8")


def _self_test() -> None:
    cases = [
        ("password", "ATHENA.MIT.EDUraeburn", 1, 16, "42263c6e89f4fc28b8df68ee09799f15"),
        ("password", "ATHENA.MIT.EDUraeburn", 2, 16, "c651bf29e2300ac27fa469d693bdda13"),
        (
            "password",
            "ATHENA.MIT.EDUraeburn",
            1,
            32,
            "fe697b52bc0d3ce14432ba036a92e65bbb52280990a2fa27883998d72af30161",
        ),
        (
            "password",
            "ATHENA.MIT.EDUraeburn",
            1200,
            32,
            "55a6ac740ad17b4846941051e1e8b0a7548d93b0ab30a8bc3ff16280382b8c2a",
        ),
    ]
    for password, salt, iterations, size, expected in cases:
        got = string_to_key(password, salt, iterations, size).hex()
        if got != expected:
            raise SystemExit(f"RFC 3962 vector failed for iter={iterations} size={size}")
    key = string_to_key("password", "ATHENA.MIT.EDUraeburn", 1, 16)
    with tempfile.TemporaryDirectory() as directory:
        path = Path(directory) / "test.keytab"
        write_keytab(path, "om/host.example.com@EXAMPLE.COM", 3, {AES128: key, AES256: key + key})
        data = path.read_bytes()
        if data[:2] != b"\x05\x02":
            raise SystemExit("keytab version is not 0x0502")
        length = struct.unpack("!i", data[2:6])[0]
        if length <= 0 or 6 + length > len(data):
            raise SystemExit("keytab entry length is corrupt")
    print("ad_user_keytab self-test ok")


def _kinit_trace(principal: str, password: str) -> str:
    ccache = tempfile.NamedTemporaryFile(prefix="krb5cc_ad_", delete=False)
    ccache.close()
    trace_file = tempfile.NamedTemporaryFile(prefix="krb5trace_", delete=False)
    trace_file.close()
    pid, fd = pty.fork()
    if pid == 0:
        os.environ["KRB5CCNAME"] = "FILE:" + ccache.name
        os.environ["KRB5_TRACE"] = trace_file.name
        os.execvp("kinit", ["kinit", principal])
    sent = False
    deadline = time.time() + 30
    try:
        while time.time() < deadline:
            ready, _, _ = select.select([fd], [], [], 1)
            if not ready:
                wait_pid, _status = os.waitpid(pid, os.WNOHANG)
                if wait_pid == pid:
                    break
                continue
            try:
                chunk = os.read(fd, 4096)
            except OSError:
                break
            if not chunk:
                break
            if not sent and b"Password" in chunk:
                os.write(fd, password.encode("utf-8") + b"\n")
                sent = True
        _pid, status = os.waitpid(pid, 0)
        trace = Path(trace_file.name).read_text(errors="replace")
        if os.waitstatus_to_exitcode(status) != 0:
            raise SystemExit(
                "kinit failed while discovering the AD string-to-key salt for "
                f"{principal}. Check krb5.conf, the KDC, and the service account."
            )
        if not sent:
            raise SystemExit(f"kinit did not prompt for {principal}")
        return trace
    finally:
        try:
            os.close(fd)
        except OSError:
            pass
        for leftover in (ccache.name, trace_file.name):
            try:
                os.remove(leftover)
            except OSError:
                pass
        subprocess.run(
            ["kdestroy", "-c", "FILE:" + ccache.name],
            check=False,
            capture_output=True,
        )


def _parse_salt(trace: str) -> tuple[str, int]:
    matches = list(
        re.finditer(
            r'salt "([^"]*)", params "([^"]*)"',
            trace,
        )
    )
    if not matches:
        raise SystemExit("KDC trace did not include an AES string-to-key salt")
    chosen = matches[-1]
    for match in matches:
        window = trace[max(0, match.start() - 80):match.end()]
        if "aes256" in window:
            chosen = match
            break
    salt = chosen.group(1)
    params = re.sub(r"\s+", "", chosen.group(2))
    iterations = int(params, 16) if params else 4096
    if iterations <= 0:
        raise SystemExit("KDC returned a zero string-to-key iteration count")
    return salt, iterations


def write_from_kdc(principal: str, password_file: Path, keytab: Path, kvno: int) -> None:
    password = read_password(password_file)
    trace = _kinit_trace(principal, password)
    salt, iterations = _parse_salt(trace)
    keys = {
        AES256: string_to_key(password, salt, iterations, 32),
        AES128: string_to_key(password, salt, iterations, 16),
    }
    write_keytab(keytab, principal, kvno, keys)


def emit_ldif(dn: str, password_file: Path, upn: str, spn: str, sam: str, destination: Path) -> None:
    password = read_password(password_file)
    quoted = ('"' + password + '"').encode("utf-16-le")
    encoded = __import__("base64").b64encode(quoted).decode("ascii")
    lines = [
        f"dn: {dn}",
        "changetype: modify",
        "replace: unicodePwd",
        f"unicodePwd:: {encoded}",
        "-",
        "replace: userAccountControl",
        "userAccountControl: 66048",
        "-",
        "replace: userPrincipalName",
        f"userPrincipalName: {upn}",
        "-",
        "replace: msDS-SupportedEncryptionTypes",
        "msDS-SupportedEncryptionTypes: 24",
    ]
    if spn:
        lines.extend([
            "-",
            "replace: servicePrincipalName",
            f"servicePrincipalName: {spn}",
        ])
    if sam and sam.lower() in password.lower():
        raise SystemExit("generated password contains the account name")
    destination.write_text("\n".join(lines) + "\n", encoding="utf-8")
    os.chmod(destination, 0o400)


def generate_password(destination: Path, sam: str) -> None:
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789"
    symbols = "!@#%+-_"
    import secrets
    chunks = [
        secrets.choice("ABCDEFGHJKLMNPQRSTUVWXYZ"),
        secrets.choice("abcdefghijkmnopqrstuvwxyz"),
        secrets.choice("23456789"),
        secrets.choice(symbols),
    ]
    chunks.extend(secrets.choice(alphabet + symbols) for _ in range(28))
    secrets.SystemRandom().shuffle(chunks)
    password = "".join(chunks)
    if sam and sam.lower() in password.lower():
        generate_password(destination, sam)
        return
    destination.write_text(password + "\n", encoding="utf-8")
    os.chmod(destination, 0o400)


def main() -> None:
    parser = argparse.ArgumentParser(description="AD AES keytab helper")
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--write-keytab", action="store_true")
    parser.add_argument("--emit-ldif", action="store_true")
    parser.add_argument("--generate-password", action="store_true")
    parser.add_argument("--principal", default=os.environ.get("KT_PRINCIPAL", ""))
    parser.add_argument("--password-file", default=os.environ.get("KT_PASSWORD_FILE", ""))
    parser.add_argument("--keytab", default=os.environ.get("KT_KEYTAB", ""))
    parser.add_argument("--kvno", type=int, default=int(os.environ.get("KT_KVNO", "1")))
    parser.add_argument("--dn", default=os.environ.get("KT_DN", ""))
    parser.add_argument("--upn", default=os.environ.get("KT_UPN", ""))
    parser.add_argument("--spn", default=os.environ.get("KT_SPN", ""))
    parser.add_argument("--sam", default=os.environ.get("KT_SAM", ""))
    parser.add_argument("--ldif", default=os.environ.get("KT_LDIF", ""))
    args = parser.parse_args()
    os.umask(0o077)
    if args.self_test:
        _self_test()
        return
    if args.generate_password:
        generate_password(Path(args.password_file), args.sam)
        return
    if args.emit_ldif:
        emit_ldif(
            args.dn,
            Path(args.password_file),
            args.upn,
            args.spn,
            args.sam,
            Path(args.ldif),
        )
        return
    if args.write_keytab:
        write_from_kdc(args.principal, Path(args.password_file), Path(args.keytab), args.kvno)
        return
    parser.error("choose --self-test, --generate-password, --emit-ldif, or --write-keytab")


if __name__ == "__main__":
    main()
