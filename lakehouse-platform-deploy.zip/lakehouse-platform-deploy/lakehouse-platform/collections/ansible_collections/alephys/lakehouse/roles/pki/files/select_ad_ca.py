#!/usr/bin/env python3
"""Select the LDAPS certificate whose SHA256 matches the pinned fingerprint.

Reads an openssl s_client -showcerts transcript on stdin and writes the
matching PEM to stdout. Exits non-zero when nothing matches, so the caller
does not add an unverified certificate to the truststore.
"""

from __future__ import annotations

import argparse
import hashlib
import re
import subprocess
import sys
from pathlib import Path


def _fingerprint(pem: str) -> str:
    der = subprocess.run(
        ["openssl", "x509", "-outform", "DER"],
        input=pem.encode("ascii"),
        capture_output=True,
        check=True,
    ).stdout
    digest = hashlib.sha256(der).hexdigest().upper()
    return ":".join(digest[index:index + 2] for index in range(0, len(digest), 2))


def _normalize(value: str) -> str:
    compact = re.sub(r"[^0-9A-Fa-f]", "", value).upper()
    return ":".join(compact[index:index + 2] for index in range(0, len(compact), 2))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--expected", required=True)
    parser.add_argument("--bundle", default="")
    args = parser.parse_args()
    expected = _normalize(args.expected)
    if args.bundle:
        transcript = Path(args.bundle).read_text(encoding="utf-8", errors="replace")
    else:
        transcript = sys.stdin.read()
    pems = re.findall(
        r"-----BEGIN CERTIFICATE-----.*?-----END CERTIFICATE-----",
        transcript,
        flags=re.DOTALL,
    )
    if not pems:
        sys.exit("LDAPS presented no certificate. Refusing to trust it.")
    for pem in pems:
        if _fingerprint(pem) == expected:
            sys.stdout.write(pem if pem.endswith("\n") else pem + "\n")
            return
    sys.exit(
        "AD CA SHA256 does not match ad_ca_sha256. "
        "Refusing to trust the certificate presented by LDAPS."
    )


if __name__ == "__main__":
    main()
