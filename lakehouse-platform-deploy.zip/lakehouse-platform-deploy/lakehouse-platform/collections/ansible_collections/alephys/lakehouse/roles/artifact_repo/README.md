# artifact_repo

nginx terminates TLS on `127.0.0.1:8448` (`artifact_repo_listen_port`).
`ports.artifact_repo_https` and `ports.haproxy_https` are both 443, so this
role does not bind nginx to 443. The haproxy role reverse-proxies public
`artifact_repo_base_url` (`https://clientopensourcetest3.infra.alephys.com/repo`)
to `127.0.0.1:8448`. Cluster nodes download only from `artifact_repo_base_url`.
`artifact_repo_upstream_url` defaults to that same URL.

Certificates come from `/etc/lakehouse/pki` (the pki role). Upstream pulls run
only on the `artifact_repo` host, and only when `download_artifacts | default(true)`
and the play is not in check mode. Provenance is written to
`artifacts/manifest.lock.yml` on the control node and to `/repo/manifest.lock.yml`.
