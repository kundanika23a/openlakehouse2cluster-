#!/usr/bin/env python3
"""Merge KMS ACL properties into Ranger dbks-site.xml without touching secrets."""

import json
import sys
import xml.etree.ElementTree as ET


def values(root):
    found = {}
    for prop in root.findall("property"):
        name = prop.findtext("name")
        if name:
            found[name] = prop.findtext("value")
    return found


def main():
    site_path, payload_path = sys.argv[1], sys.argv[2]
    with open(payload_path, "r", encoding="utf-8") as handle:
        acls = json.load(handle)
    tree = ET.parse(site_path)
    root = tree.getroot()
    before = values(root)
    existing = {prop.findtext("name"): prop for prop in root.findall("property")}
    changed = False
    for name, value in acls.items():
        if "*" in str(value):
            sys.stderr.write("refusing an ACL that contains a wildcard\n")
            return 2
        prop = existing.get(name)
        if prop is None:
            prop = ET.SubElement(root, "property")
            name_el = ET.SubElement(prop, "name")
            name_el.text = name
            value_el = ET.SubElement(prop, "value")
            value_el.text = str(value)
            existing[name] = prop
            changed = True
            continue
        value_el = prop.find("value")
        if value_el is None:
            value_el = ET.SubElement(prop, "value")
        if value_el.text != str(value):
            value_el.text = str(value)
            changed = True
    after = values(tree.getroot())
    for name, value in before.items():
        if name in acls:
            continue
        if after.get(name) != value:
            sys.stderr.write("refusing to rewrite an existing KMS property\n")
            return 2
    if changed:
        tree.write(site_path, encoding="UTF-8", xml_declaration=True)
        print("changed")
    else:
        print("ok")
    return 0


if __name__ == "__main__":
    sys.exit(main())
