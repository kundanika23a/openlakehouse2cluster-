#!/usr/bin/env python3
"""Project an API document onto the desired document and compare them."""

import json
import sys


def project(template, value):
    if isinstance(template, dict):
        if not isinstance(value, dict):
            return None
        return {key: project(template[key], value.get(key)) for key in template}
    if isinstance(template, list):
        if not isinstance(value, list) or len(value) != len(template):
            return None
        return [project(template[index], value[index]) for index in range(len(template))]
    return value


def main():
    with open(sys.argv[1], encoding="utf-8") as existing_file:
        existing = json.load(existing_file)
    with open(sys.argv[2], encoding="utf-8") as desired_file:
        desired = json.load(desired_file)
    print("same" if project(desired, existing) == desired else "drift")


if __name__ == "__main__":
    main()
