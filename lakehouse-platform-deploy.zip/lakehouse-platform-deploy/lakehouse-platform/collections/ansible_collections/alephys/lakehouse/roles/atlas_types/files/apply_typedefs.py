#!/usr/bin/python3
"""Apply Atlas typedefs and the business glossary. GET then POST.

Prints changed or unchanged. Uses the atlas service keytab.
"""

import json
import os
import subprocess
import sys
import urllib.parse
from pathlib import Path


def main() -> int:
    keytab, principal, ccache, base, ca, typedefs_path, glossary_path = sys.argv[1:8]
    Path(ccache).parent.mkdir(parents=True, exist_ok=True)
    kinit = subprocess.run(
        ["kinit", "-kt", keytab, "-c", ccache, principal],
        capture_output=True,
        text=True,
        check=False,
    )
    if kinit.returncode != 0:
        sys.stderr.write(kinit.stderr)
        return kinit.returncode or 1
    os.environ["KRB5CCNAME"] = ccache
    changed = False
    try:
        typedefs = json.loads(Path(typedefs_path).read_text())
        missing = []
        for item in typedefs.get("classificationDefs", []):
            probe = api("GET", f"{base}/api/atlas/v2/types/typedef/name/{urllib.parse.quote(item['name'])}", ca)
            if probe.returncode == 0:
                continue
            missing.append(item)
        if missing:
            body = dict(typedefs)
            body["classificationDefs"] = missing
            created = api("POST", f"{base}/api/atlas/v2/types/typedefs", ca, json.dumps(body))
            if created.returncode != 0:
                sys.stderr.write(created.stdout + created.stderr)
                return created.returncode or 1
            changed = True
        glossary = json.loads(Path(glossary_path).read_text())
        if sync_glossary(base, ca, glossary):
            changed = True
    finally:
        subprocess.run(["kdestroy", "-c", ccache], check=False)
    print("changed" if changed else "unchanged")
    return 0


def sync_glossary(base, ca, glossary) -> bool:
    listed = api("GET", f"{base}/api/atlas/v2/glossary", ca)
    if listed.returncode != 0:
        sys.stderr.write(listed.stdout + listed.stderr)
        raise SystemExit(listed.returncode or 1)
    glossaries = json.loads(listed.stdout or "[]")
    anchor = next((item for item in glossaries if item.get("name") == glossary["name"]), None)
    changed = False
    if anchor is None:
        created = api(
            "POST",
            f"{base}/api/atlas/v2/glossary",
            ca,
            json.dumps({key: glossary[key] for key in ("name", "shortDescription", "longDescription", "language", "usage")}),
        )
        if created.returncode != 0:
            sys.stderr.write(created.stdout + created.stderr)
            raise SystemExit(created.returncode or 1)
        anchor = json.loads(created.stdout)
        changed = True
    guid = anchor["guid"]
    terms = api("GET", f"{base}/api/atlas/v2/glossary/{guid}/terms?limit=-1", ca)
    if terms.returncode != 0:
        sys.stderr.write(terms.stdout + terms.stderr)
        raise SystemExit(terms.returncode or 1)
    have = {item.get("name") for item in json.loads(terms.stdout or "[]")}
    for term in glossary.get("terms", []):
        if term["name"] in have:
            continue
        payload = {"name": term["name"], "shortDescription": term["shortDescription"], "anchor": {"glossaryGuid": guid}}
        made = api("POST", f"{base}/api/atlas/v2/glossary/term", ca, json.dumps(payload))
        if made.returncode != 0:
            sys.stderr.write(made.stdout + made.stderr)
            raise SystemExit(made.returncode or 1)
        changed = True
    return changed


def api(method, url, ca, body=None):
    command = ["curl", "--silent", "--show-error", "--cacert", ca, "--negotiate", "-u", ":", "-X", method, url]
    if body is None:
        command.insert(1, "--fail")
    else:
        command[1:1] = ["--fail-with-body", "-H", "Content-Type: application/json", "--data", body]
    return subprocess.run(command, capture_output=True, text=True, check=False)


if __name__ == "__main__":
    sys.exit(main())
