#!/usr/bin/python
# -*- coding: utf-8 -*-

from __future__ import absolute_import, division, print_function

__metaclass__ = type

DOCUMENTATION = r"""
---
module: knox_topology
short_description: Write one Knox topology file
description:
  - Renders a Knox topology XML document.
  - Check mode compares the file and does not write it.
options:
  name:
    description: Topology name.
    required: true
    type: str
  dest:
    description: Destination path.
    required: true
    type: str
  services:
    description: Services with role and url.
    type: list
    elements: dict
    default: []
  applications:
    description: Knox applications such as home. They do not have a backend URL.
    type: list
    elements: dict
    default: []
  providers:
    description: Providers with role, name, enabled, and params.
    type: list
    elements: dict
    default: []
  owner:
    description: File owner. Leave unset to keep the current user.
    type: str
  group:
    description: File group.
    type: str
  mode:
    description: File mode.
    type: str
    default: "0640"
  state:
    description: Whether the file should exist.
    type: str
    choices: [present, absent]
    default: present
author:
  - Alephys Platform Engineering
"""

EXAMPLES = r"""
- name: Render the UI topology
  alephys.lakehouse.knox_topology:
    name: ui
    dest: /etc/lakehouse/knox/topologies/ui.xml
    services:
      - role: ATLAS
        url: https://clientopensourcetest2.infra.alephys.com:21443
"""

RETURN = r"""
changed:
  description: Whether the file differed.
  type: bool
  returned: always
dest:
  description: Destination path.
  type: str
  returned: always
"""

import os
import xml.sax.saxutils as sax

from ansible.module_utils.basic import AnsibleModule


def _esc(value):
    return sax.escape(str(value), {'"': "&quot;"})


def _render(name, providers, services, applications):
    lines = [
        "<!-- Managed by Ansible. Do not edit. -->",
        "<topology>",
        "  <name>%s</name>" % _esc(name),
        "  <gateway>",
    ]
    for provider in providers:
        lines.append("    <provider>")
        lines.append("      <role>%s</role>" % _esc(provider["role"]))
        lines.append("      <name>%s</name>" % _esc(provider.get("name", provider["role"])))
        enabled = provider.get("enabled", True)
        lines.append("      <enabled>%s</enabled>" % ("true" if enabled else "false"))
        for param in provider.get("params") or []:
            lines.append("      <param>")
            lines.append("        <name>%s</name>" % _esc(param["name"]))
            lines.append("        <value>%s</value>" % _esc(param["value"]))
            lines.append("      </param>")
        lines.append("    </provider>")
    lines.append("  </gateway>")
    for application in applications:
        lines.append("  <application>")
        lines.append("    <name>%s</name>" % _esc(application["name"]))
        lines.append("  </application>")
    for service in services:
        lines.append("  <service>")
        lines.append("    <role>%s</role>" % _esc(service["role"]))
        if service.get("url"):
            lines.append("    <url>%s</url>" % _esc(service["url"]))
        lines.append("  </service>")
    lines.append("</topology>")
    lines.append("")
    return "\n".join(lines)


def _apply_meta(module, path):
    mode = int(module.params["mode"], 8)
    os.chmod(path, mode)
    if module.params["owner"] or module.params["group"]:
        import grp
        import pwd

        uid = -1
        gid = -1
        if module.params["owner"]:
            uid = pwd.getpwnam(module.params["owner"]).pw_uid
        if module.params["group"]:
            gid = grp.getgrnam(module.params["group"]).gr_gid
        os.chown(path, uid, gid)


def main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type="str", required=True),
            dest=dict(type="str", required=True),
            services=dict(type="list", elements="dict", default=[]),
            applications=dict(type="list", elements="dict", default=[]),
            providers=dict(type="list", elements="dict", default=[]),
            owner=dict(type="str"),
            group=dict(type="str"),
            mode=dict(type="str", default="0640"),
            state=dict(type="str", default="present", choices=["present", "absent"]),
        ),
        supports_check_mode=True,
    )
    dest = module.params["dest"]
    for service in module.params["services"]:
        if "role" not in service:
            module.fail_json(msg="Each Knox service needs a role.")
        if "url" not in service and not str(service["role"]).startswith("KNOX-"):
            module.fail_json(msg="Each Knox service needs role and url.")
    if module.params["state"] == "absent":
        if not os.path.exists(dest):
            module.exit_json(changed=False, dest=dest)
        if module.check_mode:
            module.exit_json(changed=True, dest=dest)
        os.remove(dest)
        module.exit_json(changed=True, dest=dest)

    rendered = _render(
        module.params["name"],
        module.params["providers"],
        module.params["services"],
        module.params["applications"],
    )
    current = None
    if os.path.exists(dest):
        with open(dest, "r", encoding="utf-8") as handle:
            current = handle.read()
    if current == rendered:
        module.exit_json(changed=False, dest=dest)
    if module.check_mode:
        module.exit_json(changed=True, dest=dest)
    parent = os.path.dirname(dest)
    if parent:
        os.makedirs(parent, mode=0o750, exist_ok=True)
    tmp = dest + ".tmp"
    with open(tmp, "w", encoding="utf-8") as handle:
        handle.write(rendered)
    os.replace(tmp, dest)
    _apply_meta(module, dest)
    module.exit_json(changed=True, dest=dest)


if __name__ == "__main__":
    main()
