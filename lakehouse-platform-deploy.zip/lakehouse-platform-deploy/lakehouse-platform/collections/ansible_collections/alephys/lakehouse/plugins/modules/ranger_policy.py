#!/usr/bin/python
# -*- coding: utf-8 -*-

from __future__ import absolute_import, division, print_function

__metaclass__ = type

DOCUMENTATION = r"""
---
module: ranger_policy
short_description: Create or update one Ranger policy
description:
  - Reconciles a single Ranger policy by service and name.
  - Check mode compares the desired policy and does not write.
options:
  url:
    description: Ranger Admin base URL.
    required: true
    type: str
  username:
    description: Ranger admin user.
    required: true
    type: str
  password:
    description: Ranger admin password.
    required: true
    type: str
  service:
    description: Ranger service name.
    required: true
    type: str
  name:
    description: Policy name.
    required: true
    type: str
  policy:
    description: Policy body. service and name from the module arguments win.
    required: true
    type: dict
  state:
    description: Whether the policy should exist.
    type: str
    choices: [present, absent]
    default: present
  validate_certs:
    description: Verify TLS certificates.
    type: bool
    default: true
  timeout:
    description: HTTP timeout in seconds.
    type: int
    default: 30
author:
  - Alephys Platform Engineering
"""

EXAMPLES = r"""
- name: Allow engineers to write the raw bucket
  alephys.lakehouse.ranger_policy:
    url: https://clientopensourcetest3.infra.alephys.com:6182
    username: admin
    password: "{{ vault_ranger_admin_password }}"
    service: lakehouse_ozone
    name: lh-engineers-ozone-write
    policy:
      resources:
        volume:
          values: ["lakehouse"]
      policyItems: []
"""

RETURN = r"""
changed:
  description: Whether the policy differed.
  type: bool
  returned: always
policy_name:
  description: Policy name.
  type: str
  returned: always
"""

import base64
import json
from urllib.parse import quote

from ansible.module_utils.basic import AnsibleModule
from ansible.module_utils.urls import fetch_url


COMPARE_KEYS = (
    "service",
    "name",
    "policyType",
    "isEnabled",
    "isAuditEnabled",
    "resources",
    "policyItems",
    "denyPolicyItems",
    "rowFilterPolicyItems",
    "dataMaskPolicyItems",
)


def _canon(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def _subset(policy):
    return {key: policy[key] for key in COMPARE_KEYS if key in policy}


def _same(current, desired):
    return _canon(_subset(current)) == _canon(_subset(desired))


def _call(module, url, method, payload=None):
    token = base64.b64encode(
        ("%s:%s" % (module.params["username"], module.params["password"])).encode("utf-8")
    ).decode("ascii")
    headers = {
        "Authorization": "Basic " + token,
        "Accept": "application/json",
        "Content-Type": "application/json",
    }
    data = None if payload is None else json.dumps(payload).encode("utf-8")
    response, info = fetch_url(
        module,
        url,
        data=data,
        headers=headers,
        method=method,
        timeout=module.params["timeout"],
    )
    body = ""
    if response is not None:
        body = response.read().decode("utf-8", errors="replace")
    status = info.get("status", -1)
    if status == -1:
        module.fail_json(msg="Ranger request failed: %s" % info.get("msg", "connection failed"))
    parsed = None
    if body:
        try:
            parsed = json.loads(body)
        except ValueError:
            parsed = None
    return status, parsed, body[:300]


def main():
    module = AnsibleModule(
        argument_spec=dict(
            url=dict(type="str", required=True),
            username=dict(type="str", required=True),
            password=dict(type="str", required=True, no_log=True),
            service=dict(type="str", required=True),
            name=dict(type="str", required=True),
            policy=dict(type="dict", required=True),
            state=dict(type="str", default="present", choices=["present", "absent"]),
            validate_certs=dict(type="bool", default=True),
            timeout=dict(type="int", default=30),
        ),
        supports_check_mode=True,
    )
    base = module.params["url"].rstrip("/")
    service = quote(module.params["service"], safe="")
    name = quote(module.params["name"], safe="")
    search = "%s/service/public/v2/api/policy?serviceName=%s&policyName=%s" % (base, service, name)
    status, parsed, raw = _call(module, search, "GET")
    current = None
    if status == 200:
        rows = parsed if isinstance(parsed, list) else []
        for row in rows:
            if row.get("name") == module.params["name"] and row.get("service") == module.params["service"]:
                current = row
                break
    elif status not in (200, 404):
        module.fail_json(msg="Ranger policy lookup returned HTTP %s" % status, body=raw)

    state = module.params["state"]
    if state == "absent":
        if current is None:
            module.exit_json(changed=False, policy_name=module.params["name"])
        if module.check_mode:
            module.exit_json(changed=True, policy_name=module.params["name"])
        delete = "%s/service/public/v2/api/policy/%s" % (base, current["id"])
        dstatus, _parsed, draw = _call(module, delete, "DELETE")
        if dstatus not in (200, 204):
            module.fail_json(msg="Ranger policy delete returned HTTP %s" % dstatus, body=draw)
        module.exit_json(changed=True, policy_name=module.params["name"])

    desired = dict(module.params["policy"])
    desired["service"] = module.params["service"]
    desired["name"] = module.params["name"]
    if current is not None and _same(current, desired):
        module.exit_json(changed=False, policy_name=module.params["name"])
    if module.check_mode:
        module.exit_json(changed=True, policy_name=module.params["name"])
    if current is None:
        wstatus, written, wraw = _call(module, "%s/service/public/v2/api/policy" % base, "POST", desired)
    else:
        desired["id"] = current["id"]
        wstatus, written, wraw = _call(
            module,
            "%s/service/public/v2/api/policy/%s" % (base, current["id"]),
            "PUT",
            desired,
        )
    if wstatus not in (200, 201):
        module.fail_json(msg="Ranger policy write returned HTTP %s" % wstatus, body=wraw)
    module.exit_json(changed=True, policy_name=module.params["name"])


if __name__ == "__main__":
    main()
