#!/usr/bin/python
# -*- coding: utf-8 -*-

from __future__ import absolute_import, division, print_function

__metaclass__ = type

DOCUMENTATION = r"""
---
module: atlas_typedef
short_description: Ensure one Atlas type definition
description:
  - Creates or updates one Atlas typedef.
  - Check mode compares the type and does not write.
options:
  url:
    description: Atlas base URL.
    required: true
    type: str
  username:
    description: Atlas user.
    required: true
    type: str
  password:
    description: Atlas user password.
    required: true
    type: str
  name:
    description: Type name.
    required: true
    type: str
  category:
    description: Typedef category.
    type: str
    choices: [classification, entity, enum, struct]
    default: classification
  super_types:
    description: Parent type names.
    type: list
    elements: str
    default: []
  attributes:
    description: Attribute definitions with name and type_name.
    type: list
    elements: dict
    default: []
  state:
    description: Whether the type should exist.
    type: str
    choices: [present, absent]
    default: present
  validate_certs:
    description: Verify TLS certificates.
    type: bool
    default: true
  timeout:
    description: HTTP timeout in seconds.
    type: int
    default: 30
author:
  - Alephys Platform Engineering
"""

EXAMPLES = r"""
- name: Ensure the PII classification
  alephys.lakehouse.atlas_typedef:
    url: https://clientopensourcetest2.infra.alephys.com:21443
    username: admin
    password: "{{ vault_atlas_admin_password }}"
    name: PII
    category: classification
"""

RETURN = r"""
changed:
  description: Whether the typedef differed.
  type: bool
  returned: always
type_name:
  description: Type name.
  type: str
  returned: always
"""

import base64
import json
from urllib.parse import quote

from ansible.module_utils.basic import AnsibleModule
from ansible.module_utils.urls import fetch_url

CATEGORIES = {
    "classification": "classificationDefs",
    "entity": "entityDefs",
    "enum": "enumDefs",
    "struct": "structDefs",
}


def _call(module, url, method, payload=None):
    token = base64.b64encode(
        ("%s:%s" % (module.params["username"], module.params["password"])).encode("utf-8")
    ).decode("ascii")
    headers = {
        "Authorization": "Basic " + token,
        "Accept": "application/json",
        "Content-Type": "application/json",
    }
    data = None if payload is None else json.dumps(payload).encode("utf-8")
    response, info = fetch_url(
        module,
        url,
        data=data,
        headers=headers,
        method=method,
        timeout=module.params["timeout"],
    )
    body = ""
    if response is not None:
        body = response.read().decode("utf-8", errors="replace")
    status = info.get("status", -1)
    if status == -1:
        module.fail_json(msg="Atlas request failed: %s" % info.get("msg", "connection failed"))
    parsed = None
    if body:
        try:
            parsed = json.loads(body)
        except ValueError:
            parsed = None
    return status, parsed, body[:300]


def _desired(module):
    attributes = []
    for item in module.params["attributes"] or []:
        attributes.append(
            {
                "name": item["name"],
                "typeName": item.get("type_name", item.get("typeName")),
                "isOptional": True,
                "cardinality": "SINGLE",
                "isUnique": False,
                "isIndexable": False,
            }
        )
    return {
        "name": module.params["name"],
        "superTypes": module.params["super_types"] or [],
        "attributeDefs": attributes,
    }


def _find(parsed, key, name):
    if not isinstance(parsed, dict):
        return None
    for item in parsed.get(key) or []:
        if item.get("name") == name:
            return item
    return None


def _same(current, desired):
    current_attrs = sorted((a.get("name"), a.get("typeName")) for a in current.get("attributeDefs") or [])
    desired_attrs = sorted((a.get("name"), a.get("typeName")) for a in desired.get("attributeDefs") or [])
    return (
        sorted(current.get("superTypes") or []) == sorted(desired.get("superTypes") or [])
        and current_attrs == desired_attrs
    )


def main():
    module = AnsibleModule(
        argument_spec=dict(
            url=dict(type="str", required=True),
            username=dict(type="str", required=True),
            password=dict(type="str", required=True, no_log=True),
            name=dict(type="str", required=True),
            category=dict(type="str", default="classification", choices=sorted(CATEGORIES)),
            super_types=dict(type="list", elements="str", default=[]),
            attributes=dict(type="list", elements="dict", default=[]),
            state=dict(type="str", default="present", choices=["present", "absent"]),
            validate_certs=dict(type="bool", default=True),
            timeout=dict(type="int", default=30),
        ),
        supports_check_mode=True,
    )
    key = CATEGORIES[module.params["category"]]
    base = module.params["url"].rstrip("/")
    lookup = "%s/api/atlas/v2/types/typedef/name/%s" % (base, quote(module.params["name"], safe=""))
    status, parsed, raw = _call(module, lookup, "GET")
    current = None
    if status == 200:
        current = _find(parsed, key, module.params["name"])
    elif status not in (200, 404):
        module.fail_json(msg="Atlas typedef lookup returned HTTP %s" % status, body=raw)

    if module.params["state"] == "absent":
        module.fail_json(msg="Deleting Atlas typedefs is not supported by this module.")

    desired = _desired(module)
    if current is not None and _same(current, desired):
        module.exit_json(changed=False, type_name=module.params["name"])
    if module.check_mode:
        module.exit_json(changed=True, type_name=module.params["name"])
    wstatus, _written, wraw = _call(
        module,
        "%s/api/atlas/v2/types/typedefs" % base,
        "POST",
        {key: [desired]},
    )
    if wstatus not in (200, 201):
        module.fail_json(msg="Atlas typedef write returned HTTP %s" % wstatus, body=wraw)
    module.exit_json(changed=True, type_name=module.params["name"])


if __name__ == "__main__":
    main()
