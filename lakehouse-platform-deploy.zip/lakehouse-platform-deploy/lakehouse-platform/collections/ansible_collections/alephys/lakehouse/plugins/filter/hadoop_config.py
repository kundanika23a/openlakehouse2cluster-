"""Hadoop XML, Java properties, and auth_to_local helpers."""

from __future__ import annotations

import xml.sax.saxutils as sax


HEADER = "<!-- Managed by Ansible. Do not edit. -->\n"


def _as_str(value) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    if value is None:
        return ""
    return str(value)


def hadoop_xml(properties, comment=""):
    """Render a dict as a Hadoop configuration XML document."""
    if properties is None:
        properties = {}
    if not isinstance(properties, dict):
        raise TypeError("hadoop_xml expects a dict")
    lines = ['<?xml version="1.0"?>', HEADER.rstrip()]
    if comment:
        lines.append(f"<!-- {sax.escape(str(comment))} -->")
    lines.append("<configuration>")
    for key in properties:
        value = properties[key]
        lines.append("  <property>")
        lines.append(f"    <name>{sax.escape(_as_str(key))}</name>")
        lines.append(f"    <value>{sax.escape(_as_str(value))}</value>")
        lines.append("  </property>")
    lines.append("</configuration>")
    lines.append("")
    return "\n".join(lines)


def java_properties(properties, comment=""):
    """Render a dict as a Java properties file."""
    if properties is None:
        properties = {}
    if not isinstance(properties, dict):
        raise TypeError("java_properties expects a dict")
    lines = ["# Managed by Ansible. Do not edit."]
    if comment:
        lines.append(f"# {comment}")
    for key in properties:
        raw = _as_str(properties[key])
        escaped = (
            raw.replace("\\", "\\\\")
            .replace("\n", "\\n")
            .replace("=", "\\=")
        )
        lines.append(f"{key}={escaped}")
    lines.append("")
    return "\n".join(lines)


def auth_to_local_rules(realm, headless=None, extra=None):
    """DEFAULT auth_to_local rules for one realm plus optional headless maps."""
    realm = str(realm).upper()
    rules = [f"RULE:[1:$1@$0](.*@{realm})s/@.*//"]
    rules.append(f"RULE:[2:$1@$0](.*@{realm})s/@.*//")
    if headless:
        for principal, local_user in headless.items():
            short = str(principal).split("/", 1)[0].split("@", 1)[0]
            rules.append(
                f"RULE:[1:$1@$0]({short}@{realm})s/.*/{local_user}/"
            )
    if extra:
        rules.extend(str(item) for item in extra)
    rules.append("DEFAULT")
    return "\n".join(rules)


class FilterModule:
    def filters(self):
        return {
            "hadoop_xml": hadoop_xml,
            "java_properties": java_properties,
            "auth_to_local_rules": auth_to_local_rules,
        }
